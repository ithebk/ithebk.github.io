package me.ithebk.musicstudio_ola.about;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;
import android.webkit.WebViewClient;
import android.widget.Toast;

import io.realm.Realm;
import me.ithebk.musicstudio_ola.R;
import me.ithebk.musicstudio_ola.databinding.AboutBinding;
import me.ithebk.musicstudio_ola.databinding.PlayerHistoryBinding;
import me.ithebk.musicstudio_ola.history.HistoryAdapter;
import me.ithebk.musicstudio_ola.model.MusicHistoryRealm;

/**
 * Created by bharath on 16/12/17.
 */

public class AboutActivity extends AppCompatActivity {
    AboutBinding aboutBinding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        aboutBinding = DataBindingUtil.setContentView(this, R.layout.about);
        Toast.makeText(this,"Loading web-view",Toast.LENGTH_SHORT).show();

        aboutBinding.webView.getSettings().setJavaScriptEnabled(true);
        aboutBinding.webView.setWebViewClient(new WebViewClient());
        aboutBinding.webView.loadUrl("http://www.ithebk.me/?utm_src=ola_play");
        aboutBinding.tvGooglePlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent intent = null;
                    try {
                        intent = new Intent(Intent.ACTION_VIEW);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.setData(Uri.parse("market://details?id=" + "easydo.ithebk"));
                        startActivity(intent);
                    } catch (android.content.ActivityNotFoundException a) {
                        startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://play.google.com/store/apps/details?id=" + "easydo.ithebk")));
                    }

            }
        });
    }

}
