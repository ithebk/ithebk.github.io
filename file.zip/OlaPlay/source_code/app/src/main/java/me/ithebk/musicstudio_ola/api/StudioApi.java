package me.ithebk.musicstudio_ola.api;

import java.util.List;

import me.ithebk.musicstudio_ola.model.MusicResponse;
import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by bharath on 16/12/17.
 */

public interface StudioApi {

    @GET("studio")
    Call<List<MusicResponse>> getMusic();


}
