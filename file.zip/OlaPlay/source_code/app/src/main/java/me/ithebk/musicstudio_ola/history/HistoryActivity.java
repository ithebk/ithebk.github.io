package me.ithebk.musicstudio_ola.history;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import io.realm.Case;
import io.realm.Realm;
import me.ithebk.musicstudio_ola.R;
import me.ithebk.musicstudio_ola.databinding.PlayerHistoryBinding;
import me.ithebk.musicstudio_ola.model.MusicHistoryRealm;
import me.ithebk.musicstudio_ola.model.MusicItemRealm;

/**
 * Created by bharath on 16/12/17.
 */

public class HistoryActivity extends AppCompatActivity {
    PlayerHistoryBinding playerHistoryBinding;
    private Realm realm;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        playerHistoryBinding = DataBindingUtil.setContentView(this, R.layout.player_history);
        realm = Realm.getDefaultInstance();

        playerHistoryBinding.recyclerView.setLayoutManager(new LinearLayoutManager(this));
        playerHistoryBinding.recyclerView.setAdapter(new HistoryAdapter(this,
                realm.where(MusicHistoryRealm.class)
                        .findAll(),true));

        playerHistoryBinding.ibClearHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                realm.beginTransaction();
                realm.delete(MusicHistoryRealm.class);
                realm.commitTransaction();
            }
        });
    }
}
