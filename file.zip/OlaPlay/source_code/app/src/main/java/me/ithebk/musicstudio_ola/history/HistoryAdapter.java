package me.ithebk.musicstudio_ola.history;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.BitmapImageViewTarget;

import io.realm.OrderedRealmCollection;
import io.realm.RealmRecyclerViewAdapter;
import me.ithebk.musicstudio_ola.R;
import me.ithebk.musicstudio_ola.model.MusicHistoryRealm;
import me.ithebk.musicstudio_ola.utils.Constants;
import me.ithebk.musicstudio_ola.utils.DateUtils;

/**
 * Created by bharath on 16/12/17.
 */

public class HistoryAdapter extends RealmRecyclerViewAdapter<MusicHistoryRealm, HistoryAdapter.HistoryHolder> {

    public HistoryAdapter(@NonNull Context context, @Nullable OrderedRealmCollection<MusicHistoryRealm> data, boolean autoUpdate) {
        super(context, data, autoUpdate);
    }

    @Override
    public HistoryHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new HistoryHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.music_history_card, parent, false));
    }

    @Override
    public void onBindViewHolder(final HistoryHolder holder, int position) {
        if (getData() != null && position < getData().size()) {
            MusicHistoryRealm item = getData().get(position);

            holder.tvSong.setText(item.getMusicItemRealm().getSong());
            holder.tvArtist.setText(String.format("Artists:%s",
                    item.getMusicItemRealm().getArtists()));

            if(item.getType() == Constants.HISTORY_TYPE_PLAY) {
                holder.imageType.setImageResource(R.drawable.ic_play_history_16dp);
            }
            else {
                holder.imageType.setImageResource(R.drawable.ic_file_download_16dp);
            }


            DateUtils.setDateValuesReminder(item.getTime(),holder.tvDate);

            Glide.with(context).load(item.getMusicItemRealm().getCover_image())
                    .asBitmap().centerCrop()
                    .into(new BitmapImageViewTarget(holder.imageMain) {
                        @Override
                        protected void setResource(Bitmap resource) {
                            RoundedBitmapDrawable circularBitmapDrawable =
                                    RoundedBitmapDrawableFactory.create(context.getResources(), resource);
                            circularBitmapDrawable.setCircular(true);
                            holder.imageMain.setImageDrawable(circularBitmapDrawable);
                        }
                    });
        }
    }

    public class HistoryHolder extends RecyclerView.ViewHolder {
        private ImageView imageMain, imageType;
        private TextView tvSong, tvArtist;
        private TextView tvDate;

        public HistoryHolder(View itemView) {
            super(itemView);
            imageMain = itemView.findViewById(R.id.image);
            tvSong = itemView.findViewById(R.id.song_name);
            tvArtist = itemView.findViewById(R.id.song_artists);
            tvDate = itemView.findViewById(R.id.date);
            imageType = itemView.findViewById(R.id.image_history_type);
        }
    }
}
