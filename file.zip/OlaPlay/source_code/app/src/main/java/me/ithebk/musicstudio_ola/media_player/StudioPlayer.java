package me.ithebk.musicstudio_ola.media_player;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.view.View;

import java.io.IOException;

/**
 * Created by bharath on 16/12/17.
 */

public class StudioPlayer {

    private MediaPlayer mediaPlayer;
    private boolean paused = false;
    private String prevUrl="";
    private StudioPlayerListener studioPlayerListener;


    public StudioPlayer(StudioPlayerListener studioPlayerListener) {
        this.mediaPlayer = new MediaPlayer();
        this.studioPlayerListener = studioPlayerListener;
    }

    public void playingAudio(String url) {
        if (mediaPlayer != null) {
            try {
                if(url.equalsIgnoreCase(prevUrl)) {
                    if (mediaPlayer.isPlaying()) {
                        mediaPlayer.pause();
                        paused = true;
                        // mediaPlayer.stop();
                        studioPlayerListener.onPauseMusic();
                        return;
                    }

                    if (paused) {
                        mediaPlayer.seekTo(mediaPlayer.getCurrentPosition());
                        mediaPlayer.start();
                        studioPlayerListener.onStartMusic();
                        paused = false;
                        return;
                    }

                }
                prevUrl = url;
                mediaPlayer.reset();
                mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                mediaPlayer.setDataSource(url);
                mediaPlayer.prepareAsync();
                studioPlayerListener.onLoadingMusic();
                mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mp) {
                        mp.start();
                        studioPlayerListener.onStartMusic();
                    }
                });
                mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                    @Override
                    public void onCompletion(MediaPlayer mp) {
                        studioPlayerListener.onCompleteMusic();
                    }
                });

                mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                    @Override
                    public boolean onError(MediaPlayer mediaPlayer, int i, int i1) {
                        studioPlayerListener.onFailedMusic();
                        return false;
                    }
                });

            } catch (IllegalArgumentException | IllegalStateException | IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void destroy() {
        if(mediaPlayer!=null) {
            mediaPlayer.stop();
            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    public interface StudioPlayerListener {
        void onStartMusic();
        void onPauseMusic();
        void onCompleteMusic();
        void onLoadingMusic();
        void onFailedMusic();
    }
}
