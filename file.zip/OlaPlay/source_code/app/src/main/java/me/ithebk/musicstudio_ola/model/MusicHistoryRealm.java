package me.ithebk.musicstudio_ola.model;

import io.realm.RealmObject;

/**
 * Created by bharath on 16/12/17.
 */

public class MusicHistoryRealm extends RealmObject {
    private MusicItemRealm musicItemRealm;
    private long time;
    private int type;

    public MusicItemRealm getMusicItemRealm() {
        return musicItemRealm;
    }

    public void setMusicItemRealm(MusicItemRealm musicItemRealm) {
        this.musicItemRealm = musicItemRealm;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
