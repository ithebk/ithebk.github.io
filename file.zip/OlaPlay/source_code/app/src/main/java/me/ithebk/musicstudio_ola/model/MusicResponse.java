package me.ithebk.musicstudio_ola.model;

import me.ithebk.musicstudio_ola.utils.UiUtils;

/**
 * Created by bharath on 16/12/17.
 */

public class MusicResponse {

    private String song;
    private String url;
    private String artists;
    private String cover_image;
    private int color = UiUtils.generateRandomColor();

    public String getSong() {
        return song;
    }

    public void setSong(String song) {
        this.song = song;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getArtists() {
        return artists;
    }

    public void setArtists(String artists) {
        this.artists = artists;
    }

    public String getCover_image() {
        return cover_image;
    }

    public void setCover_image(String cover_image) {
        this.cover_image = cover_image;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Song:"+song;
    }
}
