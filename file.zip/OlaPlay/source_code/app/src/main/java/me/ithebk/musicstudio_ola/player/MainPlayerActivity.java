package me.ithebk.musicstudio_ola.player;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.VectorDrawable;
import android.net.Uri;
import android.os.Build;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.SearchView;
import android.util.Pair;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.BitmapImageViewTarget;

import java.util.ArrayList;
import java.util.List;

import io.realm.Case;
import io.realm.OrderedRealmCollection;
import io.realm.Realm;
import me.ithebk.musicstudio_ola.R;
import me.ithebk.musicstudio_ola.about.AboutActivity;
import me.ithebk.musicstudio_ola.databinding.PlayerMainBinding;
import me.ithebk.musicstudio_ola.history.HistoryActivity;
import me.ithebk.musicstudio_ola.media_player.StudioPlayer;
import me.ithebk.musicstudio_ola.model.MusicItemRealm;
import me.ithebk.musicstudio_ola.model.MusicResponse;
import me.ithebk.musicstudio_ola.utils.ConnectionDetector;
import me.ithebk.musicstudio_ola.utils.Constants;
import me.ithebk.musicstudio_ola.utils.CustomPopUpWindow;
import me.ithebk.musicstudio_ola.utils.UiUtils;

public class MainPlayerActivity extends AppCompatActivity implements  PlayerPresenter.PlayerView, MusicAdapter.MusicClickListener, StudioPlayer.StudioPlayerListener {

    private PlayerPresenter playerPresenter;
    private PlayerMainBinding playerMainBinding;
    private Realm realm;
    private StudioPlayer studioPlayer;
    private MusicItemRealm musicItemPlaying;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        playerMainBinding = DataBindingUtil.setContentView(this,R.layout.player_main);
        realm = Realm.getDefaultInstance();
        studioPlayer = new StudioPlayer(this);
        initUi();
        playerPresenter = new PlayerPresenter(this);
        playerPresenter.callApi();
        playerMainBinding.btSearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String text) {
                setAdapter(text);
                return false;
            }
        });
        playerMainBinding.btSearch.setOnSearchClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setVisibility(View.GONE);
                playerMainBinding.tvTitle.setVisibility(View.GONE);
            }
        });
        playerMainBinding.btSearch.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                setVisibility(View.VISIBLE);
                return false;
            }
        });

        playerMainBinding.swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                playerPresenter.callApi();
            }
        });
        playerMainBinding.frameMusicAction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(musicItemPlaying!=null) {
                    studioPlayer.playingAudio(musicItemPlaying.getUrl());
                }
            }
        });
        playerMainBinding.tvHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainPlayerActivity.this,
                        HistoryActivity.class));
            }
        });

        playerMainBinding.ibAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainPlayerActivity.this,
                        AboutActivity.class));
            }
        });
    }

    private void setVisibility(int visibility) {
        playerMainBinding.tvTitle.setVisibility(visibility);
        playerMainBinding.tvHistory.setVisibility(visibility);
        playerMainBinding.ibAbout.setVisibility(visibility);
    }

    private void initUi() {

        playerMainBinding.recyclerView.setLayoutManager(new GridLayoutManager(this,
                2));

        //Setting adapter for recyclerView
        setAdapter("");

        playerMainBinding.btSearch.setMaxWidth(Integer.MAX_VALUE);
        playerMainBinding.swipeRefreshLayout.setRefreshing(true);
    }
    private void setAdapter(String query) {

        OrderedRealmCollection<MusicItemRealm> orderedRealmCollection =
                realm.where(MusicItemRealm.class)
                        .contains("song",query, Case.INSENSITIVE)
                        .findAll();
        playerMainBinding.recyclerView.setAdapter(new MusicAdapter(getApplicationContext(),
                orderedRealmCollection,
                true, this));

    }

    @Override
    public void updateInitialView(List<MusicResponse> musicResponses) {
        playerMainBinding.swipeRefreshLayout.setRefreshing(false);
        if(musicResponses ==null ){
            Toast.makeText(this,
                    "Failed to load music from server",Toast.LENGTH_LONG).show();
        }

    }

    @Override
    public void errorInsertingData() {

    }

    @Override
    public void onMusicItemClicked(MusicItemRealm musicItemRealm) {
        if(!ConnectionDetector.isOnline(this)) {
           Toast.makeText(this,"No internet connection",Toast.LENGTH_SHORT).show();
           return;
        }
        this.musicItemPlaying = musicItemRealm;
        playerMainBinding.songNameBottom.setText(musicItemRealm.getSong());
        playerMainBinding.songArtistsBottom.setText(String.format("Artist%s",
                musicItemRealm.getArtists()));
        Glide.with(this).load(musicItemRealm.getCover_image())
                .asBitmap().centerCrop()
                .into(new BitmapImageViewTarget(playerMainBinding.imageBottom) {
                    @Override
                    protected void setResource(Bitmap resource) {
                        RoundedBitmapDrawable circularBitmapDrawable =
                                RoundedBitmapDrawableFactory.create(getResources(), resource);
                        circularBitmapDrawable.setCircular(true);
                        playerMainBinding.imageBottom.setImageDrawable(circularBitmapDrawable);
                    }
                });

        studioPlayer.playingAudio(musicItemRealm.getUrl());


    }

    @Override
    public void onMusicItemOptionClicked(View view,MusicItemRealm musicItemRealm) {
        initiatePopupWindow(view,musicItemRealm);
    }

    private void initiatePopupWindow(View v, final MusicItemRealm musicItemRealm) {
        List<Pair<Integer, String>> simpleEntries = new ArrayList<>();
        simpleEntries.add(new Pair<>(0, "Download"));
        simpleEntries.add(new Pair<>(0,
                musicItemRealm.isFavorite() ? "Remove Favorite":"Favorite"));
       // simpleEntries.add(new Pair<>(1, "Add to Favorite"));
        new CustomPopUpWindow(this,v,simpleEntries).show(new CustomPopUpWindow.CustomPopupWindowClickListener() {
            @Override
            public void onPopupWindowClickListener(Pair<Integer, String> entry, int position) {
                if(position == 0){


                    Toast.makeText(MainPlayerActivity.this, "Not yet implemented", Toast.LENGTH_SHORT).show();


                    Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                            Uri.parse(musicItemRealm.getUrl()));
                    startActivity(browserIntent);
                    playerPresenter.addItemToHistory(musicItemRealm, Constants.HISTORY_TYPE_DOWNLOAD);
                }
                else if(position == 1) {
                    playerPresenter.changeFavorite(musicItemRealm);
                }
            }
        });
    }

    @Override
    public void onStartMusic() {
        playerMainBinding.ibMusicProgress.setVisibility(View.GONE);
        playerMainBinding.ibMusicAction.setVisibility(View.VISIBLE);
        playerMainBinding.ibMusicAction.setImageResource(R.drawable.ic_pause_24dp);
    }

    @Override
    public void onPauseMusic() {
        playerMainBinding.ibMusicAction.setImageResource(R.drawable.ic_play_arrow_24dp);


    }

    @Override
    public void onCompleteMusic() {
        playerMainBinding.ibMusicAction.setImageResource(R.drawable.ic_play_arrow_24dp);
    }

    @Override
    public void onLoadingMusic() {
        playerMainBinding.ibMusicProgress.setVisibility(View.VISIBLE);
        playerMainBinding.ibMusicAction.setVisibility(View.GONE);
        playerPresenter.addItemToHistory(musicItemPlaying, Constants.HISTORY_TYPE_PLAY);
    }

    @Override
    public void onFailedMusic() {
        Toast.makeText(this,"Failed to load music",Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        studioPlayer.destroy();
        super.onDestroy();
    }
}
