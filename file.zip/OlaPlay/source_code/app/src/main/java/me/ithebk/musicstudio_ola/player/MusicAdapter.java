package me.ithebk.musicstudio_ola.player;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.BitmapImageViewTarget;


import io.realm.OrderedRealmCollection;
import io.realm.RealmRecyclerViewAdapter;
import me.ithebk.musicstudio_ola.R;
import me.ithebk.musicstudio_ola.model.MusicItemRealm;
import me.ithebk.musicstudio_ola.utils.UiUtils;

/**
 * Created by bharath on 16/12/17.
 */

public class MusicAdapter extends RealmRecyclerViewAdapter<MusicItemRealm, MusicAdapter.MusicViewHolder> {

    private MusicClickListener musicClickListener;

    public MusicAdapter(@NonNull Context context,
                        @Nullable OrderedRealmCollection<MusicItemRealm> data,
                        boolean autoUpdate,
                        MusicClickListener musicClickListener) {
        super(context, data, autoUpdate);
        this.musicClickListener = musicClickListener;
    }

    @Override
    public MusicViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MusicViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.music_card, parent, false));
    }

    @Override
    public void onBindViewHolder(final MusicViewHolder holder, int position) {
        if(getData()!=null && position < getData().size()) {
            final MusicItemRealm musicItemRealm = getData().get(position);
            if(musicItemRealm!=null) {
                holder.songName.setText(musicItemRealm.getSong());
                holder.songArtists.setText(String.format("Artist: %s",
                        musicItemRealm.getArtists()));

                holder.cardView.setCardBackgroundColor(musicItemRealm.getColor());

                System.out.println("Image URL:"+musicItemRealm.getCover_image());

                if(musicItemRealm.isFavorite()) {
                    holder.imageViewIsFavorite.setVisibility(View.VISIBLE);
                }
                else {
                    holder.imageViewIsFavorite.setVisibility(View.GONE);

                }
                Glide.with(context).load(musicItemRealm.getCover_image())
                        .asBitmap().centerCrop()
                        .into(new BitmapImageViewTarget(holder.imageView) {
                    @Override
                    protected void setResource(Bitmap resource) {
                        RoundedBitmapDrawable circularBitmapDrawable =
                                RoundedBitmapDrawableFactory.create(context.getResources(), resource);
                        circularBitmapDrawable.setCircular(true);
                        holder.imageView.setImageDrawable(circularBitmapDrawable);
                    }
                });
                holder.cardView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        musicClickListener.onMusicItemClicked(musicItemRealm);
                    }
                });

                holder.llOption.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        musicClickListener.onMusicItemOptionClicked(view, musicItemRealm);
                    }
                });


            }


        }
    }

    class MusicViewHolder extends RecyclerView.ViewHolder {
        private ImageView imageView;
        private TextView songName;
        private TextView songArtists;
        private CardView cardView;
        private LinearLayout llOption;
        private ImageView imageViewIsFavorite;


        MusicViewHolder(View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            imageView = (ImageView) itemView.findViewById(R.id.imageCard);
            songName = itemView.findViewById(R.id.song_name);
            songArtists = itemView.findViewById(R.id.song_artists);
            llOption = itemView.findViewById(R.id.ll_option_card);
            imageViewIsFavorite = itemView.findViewById(R.id.image_is_favorite);
        }
    }

    public interface MusicClickListener {
        void onMusicItemClicked(MusicItemRealm musicItemRealm);
        void onMusicItemOptionClicked(View view, MusicItemRealm musicItemRealm);
    }
}
