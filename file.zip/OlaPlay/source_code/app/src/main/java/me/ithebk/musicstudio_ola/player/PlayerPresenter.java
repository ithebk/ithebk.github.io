package me.ithebk.musicstudio_ola.player;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import io.realm.Realm;
import me.ithebk.musicstudio_ola.api.StudioApiUtil;
import me.ithebk.musicstudio_ola.model.MusicHistoryRealm;
import me.ithebk.musicstudio_ola.model.MusicItemRealm;
import me.ithebk.musicstudio_ola.model.MusicResponse;
import me.ithebk.musicstudio_ola.utils.UiUtils;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by bharath on 16/12/17.
 */

public class PlayerPresenter {

    List<MusicResponse> musicResponses;
    PlayerView playerView;
    private Realm realm;

    public PlayerPresenter(PlayerView playerView) {
        this.playerView = playerView;
        this.musicResponses = new ArrayList<>();
        this.realm = Realm.getDefaultInstance();
    }

    private void updateMusicResponse(final List<MusicResponse> musicResponses) {
        this.musicResponses = musicResponses;
        realm.beginTransaction();
        //realm.delete(MusicItemRealm.class);
        for (int i = 0; i < musicResponses.size(); i++) {
            MusicResponse musicResponse = musicResponses.get(i);
            musicResponse.setColor(UiUtils.generateRandomColor());
            realm.createOrUpdateObjectFromJson(MusicItemRealm.class,
                    new Gson().toJson(musicResponse));

        }

        realm.commitTransaction();
        playerView.updateInitialView(musicResponses);

    }

    public void callApi() {
        StudioApiUtil.getStudioApi().getMusic().enqueue(new Callback<List<MusicResponse>>() {
            @Override
            public void onResponse(Call<List<MusicResponse>> call, Response<List<MusicResponse>> response) {
                if (response.body() != null && response.body().size() > 0) {
                    PlayerPresenter.this.updateMusicResponse(response.body());
                }
            }

            @Override
            public void onFailure(Call<List<MusicResponse>> call, Throwable t) {
                playerView.updateInitialView(null);
            }
        });
    }

    /**
     *
     * @param musicItemRealm realm db object want to change the favorite
     */
    public void changeFavorite(MusicItemRealm musicItemRealm) {
        realm.beginTransaction();
        musicItemRealm.setFavorite(!musicItemRealm.isFavorite());
        realm.commitTransaction();
        //View update not required becuase realm auto updates view on db changes
    }

    public void addItemToHistory(MusicItemRealm musicItemPlaying, int type) {
        if(musicItemPlaying!=null) {
            realm.beginTransaction();
            MusicHistoryRealm musicHistoryRealm = new MusicHistoryRealm();
            musicHistoryRealm.setMusicItemRealm(musicItemPlaying);
            musicHistoryRealm.setTime(System.currentTimeMillis());
            musicHistoryRealm.setType(type);
            realm.copyToRealm(musicHistoryRealm);
            realm.commitTransaction();
        }

    }

    public interface PlayerView {
        void updateInitialView(List<MusicResponse> musicResponses);

        void errorInsertingData();
    }
}
