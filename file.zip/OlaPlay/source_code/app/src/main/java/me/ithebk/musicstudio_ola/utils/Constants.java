package me.ithebk.musicstudio_ola.utils;

/**
 * Created by bharath on 16/12/17.
 */

public class Constants {

    public static final String URL = "http://starlord.hackerearth.com/";
    public static final int HISTORY_TYPE_PLAY = 1;
    public static final int HISTORY_TYPE_DOWNLOAD = 2;
}
