package me.ithebk.musicstudio_ola.utils;

import android.content.Context;
import android.util.Pair;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;

import java.util.List;

/**
 * Created by bharath on 16/12/17.
 */

public class CustomPopUpWindow {
    private Context context;
    private View view;
    private List<Pair<Integer, String>> entries;

    public CustomPopUpWindow(Context context, View view, List<Pair<Integer, String>> entries) {
        this.context = context;
        this.view = view;
        this.entries = entries;
    }

    public void show(final CustomPopupWindowClickListener listener){
        if(listener == null) {
            return;
        }
        final PopupMenu popup = new PopupMenu(context, view);
        for (int i=0; i<entries.size(); i++){
            popup.getMenu().add(Menu.NONE, (Integer) entries.get(i).first, i, entries.get(i).second);
        }
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                listener.onPopupWindowClickListener(entries.get(item.getOrder()),item.getOrder());
                popup.dismiss();
                return false;
            }
        });
        popup.show();
    }

    public interface CustomPopupWindowClickListener{
        void onPopupWindowClickListener(Pair<Integer,String> entry, int position);
    }
}
