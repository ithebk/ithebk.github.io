package me.ithebk.musicstudio_ola.utils;

import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Created by bharath on 16/12/17.
 */

public class DateUtils {

    public static void setDateValuesReminder(long time, TextView tv) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(time);
        Calendar calendarTempCheckTom = (Calendar) calendar.clone();
        calendarTempCheckTom.add(Calendar.DAY_OF_MONTH, -1);

        Calendar calendarTempCheckYes = (Calendar) calendar.clone();
        calendarTempCheckYes.add(Calendar.DAY_OF_MONTH, 1);

        String hour;
        hour = new SimpleDateFormat("hh:mm aa", Locale.getDefault()).format(calendar.getTime());
        ;

        if (android.text.format.DateUtils.isToday(calendar.getTimeInMillis())) {
            tv.setText(String.format(Locale.getDefault(), "Today %s", hour));

        } else if (android.text.format.DateUtils.isToday(calendarTempCheckTom.getTimeInMillis())) {
            tv.setText(String.format(Locale.getDefault(), "Tomorrow %s", hour));
        } else if (android.text.format.DateUtils.isToday(calendarTempCheckYes.getTimeInMillis())) {
            tv.setText(String.format(Locale.getDefault(), "Yesterday %s", hour));
        } else {
            tv.setText(String.format(Locale.getDefault()
                    , "%s, %d %s, %s",
                    calendar.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.SHORT,
                            Locale.getDefault()),
                    calendar.get(Calendar.DAY_OF_MONTH),
                    calendar.getDisplayName(Calendar.MONTH, Calendar.SHORT, Locale.getDefault()),
                    hour

            ));
            if (calendar.get(Calendar.YEAR) != Calendar.getInstance().get(Calendar.YEAR)) {
                tv.setText(String.format(Locale.getDefault()
                        , "%s, %d %s, %s",
                        calendar.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.SHORT,
                                Locale.getDefault()),
                        calendar.get(Calendar.DAY_OF_MONTH),
                        calendar.getDisplayName(Calendar.MONTH, Calendar.SHORT, Locale.getDefault()),
                        calendar.get(Calendar.YEAR)));

            }
        }
    }


}
